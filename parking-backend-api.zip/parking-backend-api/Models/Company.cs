﻿namespace parking_backend_api.Models
{
    public class Company
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Telephone { get; set; }
        public int NumberOfSpacesForMotorcycles { get; set; }
        public int NumberOfSpacesForCars { get; set; }
    }
}
