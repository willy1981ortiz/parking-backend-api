﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Tests
{
    [TestClass]
    public class CompaniesControllerTests
    {
        [Fact]
        public async Task GetCompany_ReturnsCompany_WhenCompanyExists()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDbForGetCompany")
                .Options;

            // Usando un bloque using para asegurar que el contexto se desecha después de configurar los datos
            using (var context = new ApplicationDbContext(options))
            {
                context.Companies.Add(new Company { Id = 1, Name = "Test Company", Address = "Test Address", Telephone = "1234567890", NumberOfSpacesForCars = 10, NumberOfSpacesForMotorcycles = 5 });
                context.SaveChanges();
            }

            using (var context = new ApplicationDbContext(options))
            {
                var controller = new CompaniesController(context);

                // Act
                var result = await controller.GetCompany(1);

                // Assert
                var viewResult = Assert.IsType<ActionResult<Company>>(result);
                var model = Assert.IsAssignableFrom<Company>(viewResult.Value);
                Assert.Equal("Test Company", model.Name);
            }
        }
    }
}
